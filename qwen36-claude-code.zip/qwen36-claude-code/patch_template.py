#!/usr/bin/env python3
"""
Patch a Qwen3.x-family chat template so it tolerates what Claude Code sends
through llama-server's /v1/messages endpoint:

  * a second `system` message that is not at index 0
    (llama-server puts the top-level `system` param at index 0 and then
     copies Claude Code's own system-role message after it)
  * synthetic message sequences without a user turn
    (llama.cpp probes the template like that to auto-build the tool-call parser)

Usage:
  python3 patch_template.py <source> [output.jinja]

  <source> can be:
    path/to/chat_template.jinja       a template file
    path/to/model.gguf                extracts tokenizer.chat_template from GGUF metadata
    http://127.0.0.1:8080/props       a running llama-server (reads .chat_template)

  output defaults to <source-stem>-claude-code.jinja next to the source.
"""
import json
import struct
import sys
import urllib.request
from pathlib import Path

PATCHES = [
    # 1. Render a late system message instead of aborting.
    (
        "{{- raise_exception('System message must be at the beginning.') }}",
        "{{- '<|im_start|>system\\n' + content + '<|im_end|>\\n' }}",
    ),
    # 2. Don't abort when the probe sequence has no user turn.
    (
        "{{- raise_exception('No user query found in messages.') }}",
        "{{- '' }}",
    ),
]


def read_gguf_chat_template(path: Path) -> str:
    """Minimal GGUF v2/v3 metadata reader; only walks the KV header."""
    GGUF_MAGIC = b"GGUF"
    # value type ids
    U8, I8, U16, I16, U32, I32, F32, BOOL, STRING, ARRAY, U64, I64, F64 = range(13)
    scalar_fmt = {U8: "<B", I8: "<b", U16: "<H", I16: "<h", U32: "<I", I32: "<i",
                  F32: "<f", BOOL: "<?", U64: "<Q", I64: "<q", F64: "<d"}

    with open(path, "rb") as f:
        def rd(fmt):
            size = struct.calcsize(fmt)
            return struct.unpack(fmt, f.read(size))[0]

        def rd_str():
            n = rd("<Q")
            return f.read(n).decode("utf-8", errors="replace")

        def rd_value(t):
            if t == STRING:
                return rd_str()
            if t == ARRAY:
                at = rd("<I")
                n = rd("<Q")
                return [rd_value(at) for _ in range(n)]
            return rd(scalar_fmt[t])

        if f.read(4) != GGUF_MAGIC:
            raise SystemExit(f"{path} is not a GGUF file")
        version = rd("<I")
        if version < 2:
            raise SystemExit(f"unsupported GGUF version {version}")
        _n_tensors = rd("<Q")
        n_kv = rd("<Q")
        for _ in range(n_kv):
            key = rd_str()
            t = rd("<I")
            val = rd_value(t)
            if key == "tokenizer.chat_template":
                return val
    raise SystemExit("tokenizer.chat_template not found in GGUF metadata")


def load_source(src: str) -> tuple[str, str]:
    if src.startswith("http://") or src.startswith("https://"):
        with urllib.request.urlopen(src, timeout=15) as r:
            body = r.read().decode("utf-8")
        try:
            data = json.loads(body)
            tmpl = data.get("chat_template") or data["default_generation_settings"]["chat_template"]
        except (json.JSONDecodeError, KeyError, TypeError):
            tmpl = body  # raw jinja served over http
        return tmpl, "llama-server"
    p = Path(src)
    if not p.exists():
        raise SystemExit(f"no such file: {p}")
    if p.suffix.lower() == ".gguf":
        return read_gguf_chat_template(p), p.stem
    return p.read_text(encoding="utf-8"), p.stem


def main() -> None:
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    src = sys.argv[1]
    tmpl, stem = load_source(src)
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(f"{stem}-claude-code.jinja")

    applied = 0
    for old, new in PATCHES:
        if old in tmpl:
            tmpl = tmpl.replace(old, new)
            applied += 1
            print(f"patched: {old.strip()[:60]}...")
        else:
            print(f"not found (skipped): {old.strip()[:60]}...")

    leftovers = [l for l in ("System message must be at the beginning", "No user query found")
                 if l in tmpl]
    if leftovers:
        raise SystemExit(f"still present after patch: {leftovers}")

    out.write_text(tmpl, encoding="utf-8")
    print(f"\n{applied} patch(es) applied -> {out}")
    print(f"\nrun:\n  llama-server ... --jinja --chat-template-file {out}")


if __name__ == "__main__":
    main()
