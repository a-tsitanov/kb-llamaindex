#!/usr/bin/env python3
"""Render both templates with the message layout llama-server builds for Claude Code."""
import sys
from jinja2 import Environment, StrictUndefined
from jinja2.exceptions import TemplateError


def raise_exception(msg):
    raise TemplateError(msg)


def env():
    e = Environment(undefined=StrictUndefined, trim_blocks=False, lstrip_blocks=False)
    e.globals["raise_exception"] = raise_exception
    return e


# What server_chat_convert_anthropic_to_oai() produces for a Claude Code request:
# top-level `system` -> messages[0], then Claude Code's own system-role entry copied verbatim.
CLAUDE_CODE_LIKE = {
    "messages": [
        {"role": "system", "content": "You are Claude Code, Anthropic's official CLI for Claude."},
        {"role": "system", "content": "# claudeMd\nCodebase and user instructions are shown below."},
        {"role": "user", "content": "list the files in this repo"},
        {"role": "assistant", "content": "",
         "tool_calls": [{"function": {"name": "Bash", "arguments": {"command": "ls -la"}}}]},
        {"role": "tool", "content": "README.md\nsrc/"},
    ],
    "tools": [{"type": "function", "function": {
        "name": "Bash",
        "description": "Run a shell command",
        "parameters": {"type": "object", "properties": {"command": {"type": "string"}},
                       "required": ["command"]}}}],
    "add_generation_prompt": True,
}

# llama.cpp's parser-probe style sequence: tools present, no user turn at all.
PROBE_NO_USER = {
    "messages": [
        {"role": "assistant", "content": "",
         "tool_calls": [{"function": {"name": "f", "arguments": {"a": 1}}}]},
    ],
    "tools": [{"type": "function", "function": {"name": "f", "parameters": {"type": "object"}}}],
    "add_generation_prompt": False,
}


def run(path, ctx, label):
    t = env().from_string(open(path, encoding="utf-8").read())
    try:
        out = t.render(**ctx)
        print(f"[OK]   {path} :: {label}")
        return out
    except TemplateError as e:
        print(f"[FAIL] {path} :: {label} -> {e}")
        return None


if __name__ == "__main__":
    orig, patched = sys.argv[1], sys.argv[2]
    run(orig, CLAUDE_CODE_LIKE, "claude-code layout (two system msgs)")
    run(orig, PROBE_NO_USER, "parser probe (no user turn)")
    out = run(patched, CLAUDE_CODE_LIKE, "claude-code layout (two system msgs)")
    run(patched, PROBE_NO_USER, "parser probe (no user turn)")
    if out:
        print("\n===== rendered prompt (patched, claude-code layout) =====")
        print(out)
        assert out.count("<|im_start|>system") == 2, "expected two system blocks"
        assert "<tool_call>\n<function=Bash>" in out, "tool call not rendered"
        assert "<tool_response>\nREADME.md" in out, "tool response not rendered"
        assert out.rstrip().endswith("<|im_start|>assistant\n<think>"), "generation prompt missing"
        print("===== all assertions passed =====")
