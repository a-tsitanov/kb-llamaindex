# Qwen3.6-35B-A3B (HauhauCS Uncensored Aggressive) + llama.cpp + Claude Code

Исправление ошибки `Jinja Exception: System message must be at the beginning.`

## Что в папке

| Файл | Назначение |
|---|---|
| `qwen3.6-claude-code.jinja` | **Пропатченный шаблон — его и подключать.** |
| `qwen3.6-original.jinja` | Оригинал из `Qwen/Qwen3.6-35B-A3B` (базовая модель для HauhauCS), для сравнения. |
| `patch_template.py` | Скрипт патча. Умеет читать шаблон из `.jinja`, из `.gguf` или с `http://host:8080/props` работающего llama-server. Пригодится для других Qwen3.x-моделей. |
| `test_render.py` | Проверка рендера: воспроизводит раскладку сообщений, которую строит llama-server для Claude Code. |

## Что изменено (2 строки)

```diff
-    {{- raise_exception('No user query found in messages.') }}
+    {{- '' }}
…
-            {{- raise_exception('System message must be at the beginning.') }}
+            {{- '<|im_start|>system\n' + content + '<|im_end|>\n' }}
```

Первое — llama.cpp прогоняет шаблон синтетическими сообщениями без user-реплики, когда автоматически строит парсер tool-call'ов.
Второе — Claude Code присылает system и в top-level поле `system`, и внутри `messages`; llama-server при конвертации `/v1/messages` в OpenAI-формат получает два system-сообщения, и строгий шаблон Qwen обрывал запрос на втором. Теперь оно просто рендерится отдельным `<|im_start|>system` блоком.

## Запуск

```bash
llama-server \
  -m /path/to/Qwen3.6-35B-A3B-Uncensored-HauhauCS-Aggressive-Q4_K_M.gguf \
  -a qwen3.6 \
  --port 8080 -c 65536 -ngl 99 \
  --jinja --chat-template-file /Users/a.tsitanov/Downloads/qwen36-claude-code/qwen3.6-claude-code.jinja
```

(Если запускаете через `-hf HauhauCS/Qwen3.6-35B-A3B-Uncensored-HauhauCS-Aggressive:Q4_K_M` — `-m` заменяется на это, остальное то же.)

LiteLLM и настройки Claude Code трогать не нужно: в `config.yaml` остаётся `model: openai/qwen3.6` (или тот алиас, что задан через `-a`).

## Проверка

1. Запросом с двумя system-сообщениями напрямую в llama-server:

```bash
curl -s http://127.0.0.1:8080/v1/chat/completions -H 'content-type: application/json' -d '{
  "model":"qwen3.6","max_tokens":20,
  "messages":[
    {"role":"system","content":"a"},
    {"role":"system","content":"b"},
    {"role":"user","content":"hi"}
  ]}'
```

Раньше здесь был `500 … System message must be at the beginning`, теперь должен прийти обычный ответ.

2. Если что-то ещё падает — запустить `llama-server … -lv 4` и посмотреть, какие сообщения реально прилетают в упавшем запросе.

## Если поменяете модель

```bash
# из работающего сервера
python3 patch_template.py http://127.0.0.1:8080/props new-model-claude-code.jinja
# или прямо из GGUF
python3 patch_template.py /path/to/model.gguf
```

Источник решения: https://github.com/ggml-org/llama.cpp/discussions/27281
